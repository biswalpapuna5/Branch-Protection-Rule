#include <stdio.h>
#include "mylib.h"

void print_hello() {
    printf("Hello from mylib!\n");
}
