#include <stdio.h>
#include "mylib.h"

int main() {
    print_hello();
    return 0;
}
