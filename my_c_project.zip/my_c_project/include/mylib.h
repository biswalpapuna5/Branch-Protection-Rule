#ifndef MYLIB_H
#define MYLIB_H

void print_hello();

#endif
